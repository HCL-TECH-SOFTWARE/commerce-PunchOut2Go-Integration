/**
	*==================================================
	Copyright [2021] [HCL Technologies]

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0


	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
	*==================================================
**/
package com.hcl.commerce.integration.punchout.commands;

import java.util.Enumeration;

import javax.persistence.NoResultException;

import com.ibm.commerce.accesscontrol.AccessVector;
import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.me.commands.SubmitShoppingCartCmd;
import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.ras.ECTrace;

public class SubmitShoppingCartExtCmdImpl extends ControllerCommandImpl implements SubmitShoppingCartCmd {
	public static final String COPYRIGHT = "(c) Copyright International Business Machines Corporation 1996,2008";
	private Long orders_Id = null;

	private boolean checkParametersOk = false;

	protected static final String ERROR_TASK = "SubmitShoppingCartErrorView";

	protected static final String VIEW_TASK = "SubmitShoppingCartView";

	public String getErrorTask() {
		return "SubmitShoppingCartErrorView";
	}

	public Long getOrderId() {
		return orders_Id;
	}

	public AccessVector getResources() throws ECException {
		AccessVector resourceList = new AccessVector();
		OrderAccessBean orderAB = new OrderAccessBean();
		orderAB.setInitKey_orderId(getOrderId().toString());
		resourceList.addElement(orderAB);
		return resourceList;
	}

	public String getViewTask() {
		return "SubmitShoppingCartView";
	}

	public void performExecute() throws ECException {
		String strMethodName = "performExecute";

		ECTrace.entry(3L, getClass().getName(), "performExecute");

		ECTrace.trace(3L, getClass().getName(), "performExecute", "orders_Id=" + getOrderId());

		try {
			OrderAccessBean orderBean = new OrderAccessBean();

			orderBean.setInitKey_orderId(getOrderId().toString());
			orderBean.instantiateEntity();

			updateStatus(orderBean);
		} catch (NoResultException e) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, getClass().getName(), "performExecute",
					ECMessageHelper.generateMsgParms(e.toString()), e);
		}

		responseProperties = new TypedProperty();
		responseProperties.put("viewTaskName", getViewTask());
		responseProperties.put("orderId", getOrderId());

		ECTrace.exit(3L, getClass().getName(), "performExecute");
	}

	private void updateStatus(OrderAccessBean orderBean) throws ECException {
		String strMethod = "updateStatus";
		ECTrace.entry(3L, getClass().getName(), "updateStatus");
		try {
			String status_orders = orderBean.getStatus();

			if (status_orders.equalsIgnoreCase("P")) {
				orderBean.setStatus("W");
			} else {
				ECTrace.trace(3L, getClass().getName(), "updateStatus",
						"Invalid order status [status = " + status_orders + "]");
				throw new ECApplicationException(ECMessage._ERR_GENERIC, getClass().getName(), "updateStatus",
						getErrorTask(), true);
			}

			OrderItemAccessBean orderItemBean = new OrderItemAccessBean();

			Enumeration e = orderItemBean.findByOrder(getOrderId());

			while (e.hasMoreElements()) {
				OrderItemAccessBean b = (OrderItemAccessBean) e.nextElement();
				String status_orderitems = b.getStatus();

				if (status_orderitems.equalsIgnoreCase("P")) {
					b.setStatus("W");
				} else {
					ECTrace.trace(3L, getClass().getName(), "updateStatus",
							"Invalid order item status [status = " + status_orderitems + "]");
					throw new ECApplicationException(ECMessage._ERR_GENERIC, getClass().getName(), "updateStatus",
							getErrorTask(), true);
				}
			}
		} catch (NoResultException ex) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, getClass().getName(), "updateStatus", ex);
		}
		ECTrace.exit(3L, getClass().getName(), "updateStatus");
	}

	public void setOrderId(Long orderId) {
		orders_Id = orderId;
	}

	public void setRequestProperties(TypedProperty p) throws ECException {
		String strMethodName = "setRequestProperties";
		ECTrace.entry(3L, getClass().getName(), "setRequestProperties");

		requestProperties = p;

		orders_Id = p.getLong("orderId", null);

		ECTrace.exit(3L, getClass().getName(), "setRequestProperties");
	}

	public void validateParameters() throws ECException {
		String strMethodName = "validateParameters";
		ECTrace.entry(3L, getClass().getName(), "validateParameters");

		if (getOrderId() == null) {
			checkParametersOk = false;
			throw new ECApplicationException(ECMessage._ERR_ORDER_NOT_FOUND, getClass().getName(), "validateParameters",
					ECMessageHelper.generateMsgParms(getOrderId().toString(), "orderId"), getErrorTask(), true);
		}

		checkParametersOk = true;
		
		ECTrace.exit(3L, getClass().getName(), "validateParameters");
	}
}
