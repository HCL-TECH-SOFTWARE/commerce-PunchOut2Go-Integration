/**
	*==================================================
	Copyright [2021] [HCL Technologies]

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0


	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
	*==================================================
**/
package com.hcl.commerce.integration.punchout.commands;

import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.persistence.NoResultException;

import com.ibm.commerce.beans.DataBeanManager;
import com.ibm.commerce.command.CommandContext;
import com.ibm.commerce.command.CommandFactory;
import com.ibm.commerce.command.ControllerCommandImpl;
import com.ibm.commerce.common.objects.StoreAccessBean;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.edp.commands.PIAddCmd;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.me.commands.AuthenticationHelperCmd;
import com.ibm.commerce.me.commands.BatchOrderRequestCmd;
import com.ibm.commerce.me.commands.CheckBatchOrderRequestCmd;
import com.ibm.commerce.me.commands.CreateShippingBillingAddressCmd;
import com.ibm.commerce.me.common.ECMEMessage;
import com.ibm.commerce.me.common.Status;
import com.ibm.commerce.me.datatype.Address;
import com.ibm.commerce.me.datatype.CIData;
import com.ibm.commerce.me.datatype.CIDataImpl;
import com.ibm.commerce.me.datatype.PaymentInfo;
import com.ibm.commerce.me.datatype.PurchaseOrderHeader;
import com.ibm.commerce.me.datatype.PurchaseOrderItem;
import com.ibm.commerce.me.datatype.SessionInfo;
import com.ibm.commerce.me.datatype.StoreHelper;
import com.ibm.commerce.me.objects.BuyerSupplierMappingAccessBean;
import com.ibm.commerce.me.objects.ProcurementBuyerProfileAccessBean;
import com.ibm.commerce.me.objects.ProcurementProtocolAccessBean;
import com.ibm.commerce.order.commands.PrepareProcurementOrderCmd;
import com.ibm.commerce.order.commands.ProcessOrderCmd;
import com.ibm.commerce.order.objects.OrderAccessBean;
import com.ibm.commerce.order.objects.OrderItemAccessBean;
import com.ibm.commerce.order.objects.OrderItemMessagingExtensionAccessBean;
import com.ibm.commerce.order.objects.OrderMessagingExtensionAccessBean;
import com.ibm.commerce.orderitems.commands.OrderItemAddCmd;
import com.ibm.commerce.orderitems.commands.OrderItemMoveCmd;
import com.ibm.commerce.payment.beans.PaymentTCInfo;
import com.ibm.commerce.payment.beans.UsablePaymentTCListDataBean;
import com.ibm.commerce.persistence.JpaEntityAccessBeanCacheUtil;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.ras.ECTrace;
import com.ibm.commerce.server.ECConstants;
import com.ibm.commerce.server.WcsApp;
import com.ibm.commerce.user.objects.BusinessProfileAccessBean;
import com.ibm.commerce.user.objects.OrganizationAccessBean;

public class BatchOrderRequestExtCmdImpl extends ControllerCommandImpl implements BatchOrderRequestCmd {
	private static final String COPYRIGHT = "(c) Copyright International Business Machines Corporation 1996,2008";
	private static final String CLASS_NAME = "com.ibm.commerce.me.commands.BatchOrderRequestExtCmdImpl";
	private boolean checkParametersOk = false;

	private boolean validCredentials = false;

	private int errorCode = 0;

	protected long buyerId = -1L;

	protected long supplierId = -1L;

	protected Integer storeId = null;

	private Long usersId = null;

	protected Long orderId = null;

	protected Long btAddressId = null;

	protected Long stAddressId = null;

	protected CIData ciData = null;

	protected ProcurementProtocolAccessBean protocolBean = null;

	protected Integer protocolId = null;

	protected Integer authType = null;

	protected Long contractId = null;

	protected Long catalogId = null;

	protected Long memberGroupId = null;

	protected Long oldOrderId = null;

	protected String requisitionerId = null;

	protected Long organizationUnitId = null;

	private String viewTask = "PurchaseOrderView";

	private String errorTask = "PurchaseOrderErrorView";

	protected boolean solicitedOrder = false;
	private Hashtable hshDupAddress = null;

	protected Vector oldQuotes = null;

	private String orgReqId = null;

	protected void changeOrderStatus() throws ECException {
		oldQuotes = new Vector();
		boolean first = true;

		if (ciData.getPOItems() != null) {
			for (int i = 0; i < ciData.getPOItems().size(); i++) {
				PurchaseOrderItem item = (PurchaseOrderItem) ciData.getPOItems().elementAt(i);
				if (item.getShoppingCartId() != -1L) {
					setSolicitedOrder(true);
					Long quoteId = new Long(item.getShoppingCartId());
					if (first) {
						retrieveUserInfo(quoteId);
						first = false;
					}
					if (!oldQuotes.contains(quoteId)) {
						oldQuotes.addElement(quoteId);
					}
				}
			}
		}
	}

	protected int checkDuplicateOrderRequest() throws ECException {
		CheckBatchOrderRequestCmd checkPO = (CheckBatchOrderRequestCmd) CommandFactory
				.createCommand("com.ibm.commerce.me.commands.CheckBatchOrderRequestCmd", commandContext.getStoreId());
		checkPO.setCommandContext(getCommandContext());
		checkPO.setMessageId(ciData.getPOHeader().getMessageId());
		checkPO.execute();
		return checkPO.getErrorCode();
	}

	protected void checkRegistration() throws ECException {
		String strMethodName = "checkRegistration";
		ECTrace.entry(4L, getClass().getName(), strMethodName);

		try {
			SessionInfo sessionInfo = ciData.getSessionInfo();
			sessionInfo.setProcurementProtocolId(getProtocolId().toString());
			RegisterRequisitionerCmd regReqCmd = (RegisterRequisitionerCmd) CommandFactory
					.createCommand("com.ibm.commerce.me.commands.RegisterRequisitionerCmd", getStoreId());
			regReqCmd.setSessionInfo(sessionInfo);
			regReqCmd.setBuyerId(buyerId);
			regReqCmd.setSupplierId(supplierId);
			regReqCmd.setCommandContext(getCommandContext());
			regReqCmd.execute();

			usersId = regReqCmd.getUsersId();
			getCommandContext().setUserId(usersId);
		} catch (ECApplicationException expCmd) {
			ECTrace.trace(4L, getClass().getName(), strMethodName,
					"Application Exception from Registering Requisitioner" + expCmd.toString());
			throw expCmd;
		} catch (ECSystemException expCmd) {
			ECTrace.trace(4L, getClass().getName(), strMethodName,
					"Exception from Registering Requisitioner" + expCmd.toString());
			throw new ECApplicationException(ECMEMessage._ERR_PROCUREMENT_RESP_REGISTER_REQUISITIONER_FAILED,
					getClass().getName(), strMethodName, errorTask);
		}

		ECTrace.exit(4L, getClass().getName(), strMethodName);
	}

	protected void createOrderMessagingExtensionRecord(Long orderRn) throws ECException {
		String strMethodName = "createOrderMessagingExtensionRecord";

		ECTrace.entry(3L, getClass().getName(), strMethodName);

		ECTrace.trace(3L, getClass().getName(), strMethodName, "Order Refnum = " + orderRn);

		PurchaseOrderHeader poHeader = ciData.getPOHeader();
		try {
			OrderMessagingExtensionAccessBean ordMeBean = new OrderMessagingExtensionAccessBean(orderRn);

			ordMeBean.setBuyerOrderId(poHeader.getOrderId());
			ordMeBean.setPayloadId(poHeader.getMessageId());

			String s = poHeader.getComment();
			if ((s != null) && (s.length() > 1024)) {
				String s1 = s.substring(0, 1024);
				String s2 = s.substring(1025);
				ordMeBean.setComments1(s1);
				ordMeBean.setComments2(s2);
			} else {
				ordMeBean.setComments1(s);
			}

			ordMeBean.setOrderType("SA");
			if (poHeader.getOrderDate() != null) {
				ordMeBean.setRequestedTime(new Timestamp(poHeader.getOrderDate().getTime()));
			}
		} catch (Exception e) {
			errorCode = 102;
		}
		ECTrace.exit(3L, getClass().getName(), strMethodName);
	}

	protected void deleteOldOrder(Long oldOrderRn) throws ECException {
		String strMethodName = "deleteOldOrder";

		ECTrace.entry(3L, getClass().getName(), "deleteOldOrder");

		ECTrace.trace(3L, getClass().getName(), "deleteOldOrder", "attempting to delete old older = " + oldOrderRn);

		try {
			OrderAccessBean orderBean = new OrderAccessBean();

			orderBean.setInitKey_orderId(String.valueOf(oldOrderRn));
			orderBean.instantiateEntity();
			updateOrderStatus(orderBean);
		} catch (Exception e) {
			ECTrace.trace(1L, "com.ibm.commerce.me.commands.BatchOrderRequestCmdImpl", "deleteOldOrder",
					"No old order of id, " + oldOrderRn + " is found.");
		}

		OrderItemMoveCmd cmd = (OrderItemMoveCmd) CommandFactory
				.createCommand("com.ibm.commerce.orderitems.commands.OrderItemMoveCmd", getStoreId());

		TypedProperty tp = new TypedProperty();

		String s = String.valueOf(oldOrderRn);
		tp.put("fromOrderId", s);
		tp.put("deleteIfEmpty", s);
		tp.put("URL", "");
		cmd.setRequestProperties(tp);

		cmd.setCommandContext(getCommandContext());
		try {
			cmd.execute();
		} catch (ECException e) {
			ECTrace.trace(1L, "com.ibm.commerce.me.commands.BatchOrderRequestCmdImpl", "deleteOldOrder",
					"Exception: " + e.getMessage());
		}
		ECTrace.exit(3L, getClass().getName(), "deleteOldOrder");
	}

	private void updateOrderStatus(OrderAccessBean orderBean) throws ECException {
		String strMethod = "updateOrderStatus";
		ECTrace.entry(3L, getClass().getName(), "updateOrderStatus");
		try {
			String status_orders = orderBean.getStatus();

			if (status_orders.equalsIgnoreCase("W")) {
				orderBean.setStatus("P");
				OrderItemAccessBean orderItemBean = new OrderItemAccessBean();

				Enumeration e = orderItemBean.findByOrder(orderBean.getOrderIdInEntityType());

				while (e.hasMoreElements()) {
					OrderItemAccessBean b = (OrderItemAccessBean) e.nextElement();
					String status_orderitems = b.getStatus();

					if (status_orderitems.equalsIgnoreCase("W")) {
						b.setStatus("P");
					}
				}
			}
		} catch (NoResultException ex) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, getClass().getName(), "updateOrderStatus", ex);
		}
		ECTrace.exit(3L, getClass().getName(), "updateOrderStatus");
	}

	protected void determineMappingProperties() {
		String strMethodName = "determineMappingProperties";

		try {
			BuyerSupplierMappingAccessBean mappingBean = new BuyerSupplierMappingAccessBean();

			mappingBean.setInitKey_iBuyerOrganizationId(String.valueOf(buyerId));
			mappingBean.setInitKey_iSupplierOrganizationId(String.valueOf(supplierId));
			mappingBean.setInitKey_protocolId(String.valueOf(protocolId));
			mappingBean.instantiateEntity();

			catalogId = mappingBean.getCatalogIdInEntityType();
			setContractId(mappingBean.getContractIdInEntityType());
			memberGroupId = mappingBean.getMemberGroupIdInEntityType();

			ECTrace.trace(1L, "com.ibm.commerce.me.commands.BatchOrderRequestCmdImpl", strMethodName,
					"CATALOG_ID_VALUE = " + catalogId);
		} catch (Exception ex) {
			ECTrace.trace(1L, "com.ibm.commerce.me.commands.BatchOrderRequestCmdImpl", strMethodName,
					"buyerId: " + buyerId + " supplierId: " + supplierId + " protocolId: " + protocolId + " Exception: "
							+ ex.getMessage());
		}

		setStoreId(StoreHelper.findStoreId(new Long(supplierId), catalogId, getContractId()));
		if ((getStoreId() != null) && (getStoreId().intValue() != ECConstants.EC_NO_STOREID.intValue())) {
			getCommandContext().setStoreId(getStoreId());

			StoreAccessBean storeAB = WcsApp.storeRegistry.find(getStoreId());
			ECTrace.trace(3L, getClass().getName(), strMethodName, "storeId =" + getStoreId() + " store=" + storeAB);
			getCommandContext().setStore(storeAB);
		}
	}

	protected void doProcess() throws ECException {
		String strMethodName = "doProcess()";
		ECTrace.entry(3L, getClass().getName(), "doProcess()");

		boolean rc = true;

		errorCode = checkDuplicateOrderRequest();

		if (errorCode == 0) {
			validCredentials = isValidCredentials();
		}
		if (validCredentials) {
			OrganizationAccessBean orgBean = (OrganizationAccessBean) JpaEntityAccessBeanCacheUtil
					.newJpaEntityAccessBean(OrganizationAccessBean.class);
			orgBean.setInitKey_memberId(getBuyerId().toString());

			checkIsAllowed(orgBean, "com.ibm.commerce.me.commands.BatchOrderRequestCmd");

			changeOrderStatus();

			if ((orgReqId == null) && (getRequisitionerId() != null)) {
				checkRegistration();
			}
		}

		if (errorCode == 0) {
			CreateShippingBillingAddressCmd sbAddress = (CreateShippingBillingAddressCmd) CommandFactory.createCommand(
					"com.ibm.commerce.me.commands.CreateShippingBillingAddressCmd", commandContext.getStoreId());
			sbAddress.setCommandContext(getCommandContext());
			sbAddress.setAddressType("B");
			sbAddress.setBillToAddress(ciData.getBillTo());
			sbAddress.setMemberId(usersId);
			sbAddress.execute();
			btAddressId = sbAddress.getAddressId();
			errorCode = sbAddress.getErrorCode();
			if (errorCode != 0) {
				ECTrace.trace(3L, getClass().getName(), "doProcess()",
						"Creating Bill to Address Failed:  [errorCode = " + errorCode + "]");
			} else {
				ECTrace.trace(3L, getClass().getName(), "doProcess()",
						"Created Bill to Address:  [ AddressId = " + btAddressId + "]");
			}
		}

		if ((errorCode == 0) && (ciData.getPOHeader().getShipTo() != null)) {
			CreateShippingBillingAddressCmd shipAddress = (CreateShippingBillingAddressCmd) CommandFactory
					.createCommand("com.ibm.commerce.me.commands.CreateShippingBillingAddressCmd",
							getCommandContext().getStoreId());
			shipAddress.setCommandContext(getCommandContext());
			shipAddress.setAddressType("S");
			shipAddress.setShipToAddress(ciData.getPOHeader().getShipTo());
			shipAddress.setMemberId(usersId);
			shipAddress.execute();
			stAddressId = shipAddress.getAddressId();
			errorCode = shipAddress.getErrorCode();
			if (errorCode != 0) {
				ECTrace.trace(3L, getClass().getName(), "doProcess()",
						"Creating ShipTo Address failed  [errorCode = " + errorCode + "]");
			} else {
				ECTrace.trace(3L, getClass().getName(), "doProcess()",
						"Successfully created shipto address [AddressId = " + stAddressId + "]");
			}
		}

		try {
			if (ciData.getPOItems() != null) {
				processOrderItems();
			}
		} catch (ECException e) {
			errorCode = 104;
			throw e;
		}

		if (oldQuotes != null) {
			Enumeration enQuoteIds = oldQuotes.elements();
			while (enQuoteIds.hasMoreElements()) {
				Long delOrderId = (Long) enQuoteIds.nextElement();
				deleteOldOrder(delOrderId);
			}
		}

		Long orgUserId = getCommandContext().getUserId();
		Integer orgStoreId = getCommandContext().getStoreId();

		if ((errorCode == 0) && (rc)) {

			/**
			 * To add the Payment Instruction for COD
			 */
			TypedProperty tempRequestProperties = new TypedProperty();
			tempRequestProperties.put("billing_address_id", btAddressId);
			tempRequestProperties.put("policyId", "15506");
			tempRequestProperties.put("payMethodId", "COD");
			tempRequestProperties.put("piAmount", ciData.getPOHeader().getTotalAmount());
			tempRequestProperties.put("orderId", orderId);
			tempRequestProperties.put("URL", "PIAdd");

			PIAddCmd aPIAddCmd = (PIAddCmd) CommandFactory.createCommand("com.ibm.commerce.edp.commands.PIAddCmd",
					getStoreId());
			aPIAddCmd.setAccCheck(false);
			aPIAddCmd.setCommandContext((CommandContext) getCommandContext().clone());
			aPIAddCmd.setRequestProperties(tempRequestProperties);
			aPIAddCmd.execute();
			prepareOrder(orgStoreId);
		}
		if (errorCode == 0) {
			processOrder(getStoreId());
		}

		getCommandContext().setUserId(orgUserId);
		getCommandContext().setStoreId(orgStoreId);

		ECTrace.exit(3L, getClass().getName(), "doProcess()");
	}

	public Integer getAuthType() {
		return authType;
	}

	public Long getBuyerId() {
		return new Long(buyerId);
	}

	public Long getContractId() {
		return contractId;
	}

	private Long getDuplicateAddress(Address addr) {
		if ((hshDupAddress == null) || (addr == null)) {
			return null;
		}

		Long index = null;
		Enumeration e = hshDupAddress.keys();

		while (e.hasMoreElements()) {
			Long temp = (Long) e.nextElement();
			if (addr.equals(hshDupAddress.get(temp))) {
				index = temp;
				break;
			}
		}
		return index;
	}

	public Long getOrganizationUnitId() {
		return organizationUnitId;
	}

	public Integer getProtocolId() {
		return protocolId;
	}

	public String getRequisitionerId() {
		return requisitionerId;
	}

	public Integer getStoreId() {
		return storeId;
	}

	public Long getSupplierId() {
		return new Long(supplierId);
	}

	protected void initializeInputData() {
		ciData = new CIDataImpl(getCommandContext());
	}

	public boolean isGeneric() {
		return true;
	}

	protected boolean isValidCredentials() throws ECException {
		String strMethodName = "isValidCredentials";
		ECTrace.entry(4L, getClass().getName(), strMethodName);

		try {
			AuthenticationHelperCmd cmd = (AuthenticationHelperCmd) CommandFactory
					.createCommand("com.ibm.commerce.me.commands.AuthenticationHelperCmd", commandContext.getStoreId());
			cmd.setBuyerCredentials(ciData.getBuyerCredentials());
			cmd.setSupplierCredentials(ciData.getSupplierCredentials());
			cmd.setMarketPlaceBuyerCredentials(ciData.getMarketPlaceCredentials());
			cmd.setSessionInfo(ciData.getSessionInfo());
			cmd.setCommandContext(commandContext);
			cmd.setAuthType(getAuthType().intValue());
			cmd.setProtocolId(getProtocolId());

			cmd.execute();
			validCredentials = cmd.isValidCredentials();
			errorCode = cmd.getErrorCode();
			if (!validCredentials) {
				ECTrace.trace(4L, getClass().getName(), strMethodName, "Validating credentials failed");
			} else {
				buyerId = cmd.getBuyerId();
				supplierId = cmd.getSupplierId();
				setBuyerRequestProperties();

				determineMappingProperties();
			}
		} catch (ECException expCmd) {
			ECTrace.trace(4L, getClass().getName(), strMethodName, "Exeption occurred" + expCmd);
			ECTrace.exit(4L, getClass().getName(), strMethodName);
			throw expCmd;
		}
		ECTrace.exit(4L, getClass().getName(), strMethodName);
		return validCredentials;
	}

	public void performExecute() throws ECException {
		String strMethodName = "performExecute";
		ECTrace.entry(3L, getClass().getName(), "performExecute");
		boolean failed = false;

		if (!checkParametersOk) {
			ECTrace.trace(3L, getClass().getName(), "performExecute", "validateParameters failed");
			ECTrace.exit(4L, getClass().getName(), "performExecute");
			return;
		}
		responseProperties = new TypedProperty();

		String errorView = StoreHelper.getResponseErrorView(getProtocolId().toString(), getBuyerId().toString(),
				"PurchaseOrderResponse");
		if (errorView == null) {
			errorView = errorTask;
		}
		try {
			doProcess();
		} catch (ECSystemException e) {
			if (errorCode == 0) {
				errorCode = 102;
			}
			failed = true;
		} catch (ECApplicationException e) {
			if (errorCode == 0) {
				errorCode = 102;
			}

			failed = true;
		}
		if (errorCode != 0) {
			failed = true;
		}

		if (!failed) {
			String view = StoreHelper.getResponseViewName(getProtocolId().toString(), getBuyerId().toString(),
					"PurchaseOrderResponse");
			if (view == null) {
				view = viewTask;
			}

			responseProperties.put("viewTaskName", view);
		} else {
			responseProperties.put("viewTaskName", errorView);
		}

		Status stat = Status.getStatus(errorCode, getCommandContext().getLocale());

		responseProperties.put("statusCode", stat.getCode());
		responseProperties.put("statusText", stat.getText());
		responseProperties.put("statusMessage", stat.getMessage());
		responseProperties.put("procurementErrorCode", Integer.toString(errorCode));
		responseProperties.put("orderId", String.valueOf(orderId));
		ECTrace.exit(3L, getClass().getName(), "performExecute");
	}

	protected void prepareOrder(Integer aStoreId) throws ECException {
		String strMethodName = "prepareOrder";

		ECTrace.entry(3L, getClass().getName(), strMethodName);

		OrderAccessBean abOrder = new OrderAccessBean();
		abOrder.setInitKey_orderId(String.valueOf(orderId));

		Vector vOrder = new Vector(1);
		vOrder.add(abOrder);
		try {
			PrepareProcurementOrderCmd orderPrepare = (PrepareProcurementOrderCmd) CommandFactory
					.createCommand("com.ibm.commerce.order.commands.PrepareProcurementOrderCmd", aStoreId);

			orderPrepare.setCommandContext(getCommandContext());
			orderPrepare.setOrders(vOrder);
			orderPrepare.execute();
		} catch (ECException expCmd) {
			errorCode = 106;
			throw expCmd;
		}

		ECTrace.exit(3L, getClass().getName(), strMethodName);
	}

	protected void processOrder(Integer orgStoreId) throws ECException {
		String strMethodName = "processOrder";

		ECTrace.entry(3L, getClass().getName(), "processOrder");

		PaymentInfo info = ciData.getPOHeader().getPayMethod();

		TypedProperty procOrderReqParm = new TypedProperty();
		/*
		 * if (info != null) { Calendar cal = Calendar.getInstance();
		 * cal.setTime(info.getExpiration());
		 * 
		 * procOrderReqParm.put("cardNumber", info.getCardNumber());
		 * procOrderReqParm.put("cardBrand", info.getCardName());
		 * procOrderReqParm.put("cardExpiryMonth", new
		 * Integer(cal.get(2)).toString());
		 * procOrderReqParm.put("cardExpiryYear", new
		 * Integer(cal.get(1)).toString()); } else {
		 * procOrderReqParm.put("cardNumber", "2222222222");
		 * procOrderReqParm.put("cardBrand", "VISA");
		 * procOrderReqParm.put("cardExpiryMonth", "12");
		 * procOrderReqParm.put("cardExpiryYear", "2025"); }
		 */

		UsablePaymentTCListDataBean payTCBean = new UsablePaymentTCListDataBean();

		payTCBean.setOrderId(orderId);

		DataBeanManager.activate(payTCBean, getCommandContext());
		PaymentTCInfo[] payTCInfo = payTCBean.getPaymentTCInfo();

		String tcId = null;
		for (int i = 0; i < payTCInfo.length; i++) {
			if (payTCInfo[i].getPolicyName().equalsIgnoreCase("COD")) {
				procOrderReqParm.put("tcId", payTCInfo[i].getTCId());
				procOrderReqParm.put("policyId", payTCInfo[i].getPolicyId());
			}
		}

		ProcessOrderCmd processOrderCmd = (ProcessOrderCmd) CommandFactory
				.createCommand("com.ibm.commerce.order.commands.ProcessOrderCmd", orgStoreId);
		processOrderCmd.setOrderRn(orderId);
		processOrderCmd.setBillToRn(btAddressId);

		getCommandContext().setRequestProperties(procOrderReqParm);
		processOrderCmd.setCommandContext(getCommandContext());

		processOrderCmd.setPoNumber(ciData.getPOHeader().getOrderId());
		try {
			processOrderCmd.execute();
		} catch (ECException expCmd) {
			ECTrace.trace(4L, getClass().getName(), "processOrder", "ORDER_PROCESS_FAILED [orderId = " + orderId + "]");
			errorCode = 107;
			throw expCmd;
		}

		ECTrace.exit(3L, getClass().getName(), "processOrder");
	}

	protected void processOrderItems() throws ECException {
		String strMethodName = "processOrderItems";

		ECTrace.entry(3L, getClass().getName(), strMethodName);

		hshDupAddress = new Hashtable();

		Hashtable hshAddress = new Hashtable();
		Hashtable hshPartNumber = new Hashtable();

		Hashtable hshContract = new Hashtable();

		Hashtable hshQuantity = new Hashtable();
		Hashtable hshShipMode = new Hashtable();

		Hashtable hshAttrName = new Hashtable();

		Hashtable hshAttrValue = new Hashtable();

		String orderLevelShipMode = ciData.getPOHeader().getShipModeId();

		Vector poItems = ciData.getPOItems();

		Enumeration items = poItems.elements();

		int i = 0;
		while ((items != null) && (items.hasMoreElements())) {
			i++;

			PurchaseOrderItem poItem = (PurchaseOrderItem) items.nextElement();

			if (ciData.getPOHeader().getShipTo() == null) {
				stAddressId = getDuplicateAddress(poItem.getShipTo());
				if (stAddressId == null) {
					CreateShippingBillingAddressCmd shipAddress = (CreateShippingBillingAddressCmd)

					CommandFactory.createCommand("com.ibm.commerce.me.commands.CreateShippingBillingAddressCmd",
							commandContext.getStoreId());
					shipAddress.setAddressType("S");
					shipAddress.setShipToAddress(poItem.getShipTo());
					shipAddress.setMemberId(usersId);
					shipAddress.setCommandContext(getCommandContext());
					shipAddress.execute();
					stAddressId = shipAddress.getAddressId();
					errorCode = shipAddress.getErrorCode();

					if (errorCode == 0) {
						hshDupAddress.put(stAddressId, poItem.getShipTo());
					}
				}
			}

			hshAddress.put(new Integer(i), String.valueOf(stAddressId));

			double qty = poItem.getQuantityInDouble();

			hshPartNumber.put(new Integer(i), poItem.getItemId());
			hshQuantity.put(new Integer(i), String.valueOf(qty));

			String shipmodeId = poItem.getShipModeId();

			if (shipmodeId == null) {
				shipmodeId = orderLevelShipMode;
			}

			if (shipmodeId != null) {
				hshShipMode.put(new Integer(i), shipmodeId);
			}

			if (poItem.getItemAttrName() != null) {
				hshAttrName.put(new Integer(i), poItem.getItemAttrName());
			}

			if (poItem.getItemAttrValue() != null) {
				hshAttrValue.put(new Integer(i), poItem.getItemAttrValue());
			}

			if (getContractId() != null) {
				hshContract.put(new Integer(i), new String[] { getContractId().toString() });
			}
		}

		OrderItemAddCmd ordItemCmd = (OrderItemAddCmd) CommandFactory.createCommand(
				"com.ibm.commerce.orderitems.commands.OrderItemAddCmd", getCommandContext().getStoreId());

		ordItemCmd.setPartNumber(hshPartNumber);
		ordItemCmd.setQuantity(hshQuantity);

		if (hshShipMode.size() > 0) {
			ordItemCmd.setShipmodeId(hshShipMode);
		}

		if (hshAddress.size() > 0) {
			ordItemCmd.setAddressId(hshAddress);
		}

		if (hshAttrName.size() > 0) {
			ordItemCmd.setAttrName(hshAttrName);
		}

		if (hshAttrValue.size() > 0) {
			ordItemCmd.setAttrValue(hshAttrValue);
		}

		if (getContractId() != null) {
			ordItemCmd.setContractId(hshContract);
		}

		ordItemCmd.setCommandContext(getCommandContext());
		ordItemCmd.execute();

		String[] orderItemIds = ordItemCmd.getOrderItemIds();
		String[] orderIds = ordItemCmd.getOrderIds();

		if (orderIds.length == 1) {
			orderId = Long.valueOf(orderIds[0]);
		}

		createOrderMessagingExtensionRecord(orderId);

		Enumeration items2 = poItems.elements();
		for (int j = 0; j < orderItemIds.length; j++) {
			PurchaseOrderItem poItem = (PurchaseOrderItem) items2.nextElement();
			try {
				OrderItemMessagingExtensionAccessBean b2bItem = new OrderItemMessagingExtensionAccessBean(
						Long.valueOf(orderItemIds[j]));

				String s = poItem.getComments();
				if ((s != null) && (s.length() > 1024)) {
					String s1 = s.substring(0, 1024);
					String s2 = s.substring(1025);
					b2bItem.setComments1(s1);
					b2bItem.setComments2(s2);
				} else {
					b2bItem.setComments1(s);
				}

				if (poItem.getRequestedDeliveryDate() != null) {
					b2bItem.setRequestedShipTime(new Timestamp(poItem.getRequestedDeliveryDate().getTime()));
				}
			} catch (Exception e) {
				ECTrace.trace(4L, getClass().getName(), strMethodName,
						"Exception when creating the ORDIMEEXTN table entry (order item messaging extension record) "
								+ e);

				errorCode = 104;
			}
		}

		ECTrace.exit(3L, getClass().getName(), strMethodName);
	}

	protected void retrieveUserInfo(Long shoppingCartId) throws ECException {
		orgReqId = null;
		String strMethodName = "retrieveUserInfo";
		ECTrace.entry(4L, getClass().getName(), strMethodName);
		try {
			OrderAccessBean orderBean = new OrderAccessBean();
			orderBean.setInitKey_orderId(String.valueOf(shoppingCartId));
			orderBean.instantiateEntity();
			usersId = orderBean.getMemberIdInEntityType();

			BusinessProfileAccessBean busBean = new BusinessProfileAccessBean();
			busBean.setInitKey_userId(String.valueOf(usersId));
			orgReqId = busBean.getRequistionerId();
		} catch (NoResultException e) {
			ECTrace.trace(3L, getClass().getName(), strMethodName, "Finder Exception: " + e);
			errorCode = 7;
		}

		if (orgReqId != null) {
			getCommandContext().setUserId(usersId);
		}

		ECTrace.exit(4L, getClass().getName(), strMethodName);
	}

	public void setAuthType(Integer anAuthType) {
		authType = anAuthType;
	}

	public void setBuyerId(Long aBuyerId) {
		buyerId = aBuyerId.longValue();
	}

	protected void setBuyerRequestProperties() {
		if ((getProtocolId() == null) || (getBuyerId() == null)) {
			return;
		}

		String orgUnitName = null;
		String reqId = null;
		try {
			ProcurementBuyerProfileAccessBean aBean = new ProcurementBuyerProfileAccessBean();
			aBean.setInitKey_protocolId(getProtocolId().toString());
			aBean.setInitKey_organizationId(getBuyerId().toString());
			aBean.instantiateEntity();

			reqId = requestProperties.getString(aBean.getReqIdParamName(), null);
			if (reqId == null) {
				reqId = requestProperties.getString("reqId", null);
			}

			setRequisitionerId(reqId);
			ciData.getSessionInfo().setReqId(reqId);
			orgUnitName = requestProperties.getString(aBean.getOrganizationUnitParamName(), null);

		} catch (Exception e) {
			ECTrace.trace(1L, "com.ibm.commerce.me.commands.BatchOrderRequestCmdImpl", "setBuyerRequestProperties()",
					"protocolId: " + getProtocolId() + " buyerId: " + getBuyerId() + " Exception: " + e.getMessage());
		}
	}

	public void setContractId(Long aContractId) {
		contractId = aContractId;
	}

	public void setOrganizationUnitId(Long orgUnit) {
		organizationUnitId = orgUnit;
	}

	public void setProtocolId(Integer aProtocolId) {
		protocolId = aProtocolId;
	}

	public void setRequestProperties(TypedProperty p) throws ECException {
		String strMethodName = "setRequestProperties";
		ECTrace.entry(3L, getClass().getName(), "setRequestProperties");

		requestProperties = p;

		initializeInputData();
		try {
			ciData.setPOData(requestProperties);
		} catch (Exception e) {
			throw new ECApplicationException(ECMessage._ERR_GENERIC,
					"com.ibm.commerce.me.commands.BatchOrderRequestCmdImpl", "setRequestProperties",
					ECMessageHelper.generateMsgParms(e.toString()));
		}
		ECTrace.exit(3L, getClass().getName(), "setRequestProperties");
	}

	public void setRequisitionerId(String aRequisitionerId) {
		requisitionerId = aRequisitionerId;
	}

	private void setSolicitedOrder(boolean status) {
		solicitedOrder = status;
	}

	public void setStoreId(Integer aStoreId) {
		storeId = aStoreId;
	}

	public void setSupplierId(Long aSupplierId) {
		supplierId = aSupplierId.longValue();
	}

	public void validateParameters() throws ECException {
		String strMethodName = "validateParameters";

		ECTrace.entry(3L, getClass().getName(), strMethodName);

		if ((ciData.getBuyerCredentials() != null) && (ciData.getSupplierCredentials() != null)
				&& (ciData.getBuyerCredentials().getCode() != null)
				&& (ciData.getBuyerCredentials().getCode().trim().length() != 0)
				&& (ciData.getBuyerCredentials().getCodeDomain() != null)
				&& (ciData.getBuyerCredentials().getCodeDomain().trim().length() != 0)) {
			if ((ciData.getSupplierCredentials().getCode() != null)
					&& (ciData.getSupplierCredentials().getCode().trim().length() != 0)
					&& (ciData.getSupplierCredentials().getCodeDomain() != null)
					&& (ciData.getSupplierCredentials().getCodeDomain().trim().length() != 0)) {
				checkParametersOk = true;
			}
		}

		try {
			ProcurementProtocolAccessBean aBean = new ProcurementProtocolAccessBean();

			protocolBean = aBean.findByProtocolNameAndVersion(ciData.getProtocolName(), ciData.getProtocolVersion());
			protocolId = protocolBean.getProtocolIdInEntityType();
			setAuthType(protocolBean.getAuthenticationTypeInEntityType());

		} catch (Exception e) {

			checkParametersOk = false;
		}

		ECTrace.exit(3L, getClass().getName(), strMethodName);
	}
}
