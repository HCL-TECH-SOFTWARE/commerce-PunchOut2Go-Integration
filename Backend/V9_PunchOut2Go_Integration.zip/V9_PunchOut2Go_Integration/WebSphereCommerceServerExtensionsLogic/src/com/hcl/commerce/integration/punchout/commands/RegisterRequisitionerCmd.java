/**
	*==================================================
	Copyright [2021] [HCL Technologies]

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0


	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
	*==================================================
**/
package com.hcl.commerce.integration.punchout.commands;

import com.ibm.commerce.command.TaskCommand;
import com.ibm.commerce.me.datatype.SessionInfo;

public abstract interface RegisterRequisitionerCmd extends TaskCommand {
	public static final String COPYRIGHT = "(c) Copyright International Business Machines Corporation 1996,2008";
	public static final String NAME = "com.hcl.commerce.integration.punchout.commands.RegisterRequisitionerCmd";
	public static final String defaultCommandClassName = "com.hcl.commerce.integration.punchout.commands.RegisterRequisitionerExtCmdImpl";

	public abstract Long getUsersId();

	public abstract boolean isRegisteredSuccessfully();

	public abstract void setBuyerId(long paramLong);

	public abstract void setDeptName(String paramString);

	public abstract void setPostbackUrl(String paramString);

	public abstract void setProtocolId(Integer paramInteger);

	public abstract void setReqId(String paramString);

	public abstract void setSessionId(String paramString);

	public abstract void setSessionInfo(SessionInfo paramSessionInfo);

	public abstract void setSupplierId(long paramLong);

	public abstract void setEmail(String email);
}
