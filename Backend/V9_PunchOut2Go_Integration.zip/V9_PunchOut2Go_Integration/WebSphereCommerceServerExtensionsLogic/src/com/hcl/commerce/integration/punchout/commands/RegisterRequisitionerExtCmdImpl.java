/**
	*==================================================
	Copyright [2021] [HCL Technologies]

	Licensed under the Apache License, Version 2.0 (the "License");
	you may not use this file except in compliance with the License.
	You may obtain a copy of the License at

		http://www.apache.org/licenses/LICENSE-2.0


	Unless required by applicable law or agreed to in writing, software
	distributed under the License is distributed on an "AS IS" BASIS,
	WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	See the License for the specific language governing permissions and
	limitations under the License.
	*==================================================
**/
package com.hcl.commerce.integration.punchout.commands;

import java.util.Enumeration;
import java.util.Vector;

import javax.persistence.EntityExistsException;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;

import com.ibm.commerce.accesscontrol.AccessVector;
import com.ibm.commerce.base.objects.ServerJDBCHelperBean;
import com.ibm.commerce.command.CommandFactory;
import com.ibm.commerce.command.TaskCommandImpl;
import com.ibm.commerce.datatype.CacheRule;
import com.ibm.commerce.datatype.TypedProperty;
import com.ibm.commerce.dynacache.CacheConstants;
import com.ibm.commerce.ejb.helpers.SessionBeanHelper;
import com.ibm.commerce.exception.ECApplicationException;
import com.ibm.commerce.exception.ECException;
import com.ibm.commerce.exception.ECSystemException;
import com.ibm.commerce.me.common.ECMEMessage;
import com.ibm.commerce.me.common.Status;
import com.ibm.commerce.me.datatype.SessionInfo;
import com.ibm.commerce.me.datatype.StoreHelper;
import com.ibm.commerce.member.helpers.MemberRegistrationAttributesHelper;
import com.ibm.commerce.persistence.JpaEntityAccessBeanCacheUtil;
import com.ibm.commerce.ras.ECMessage;
import com.ibm.commerce.ras.ECMessageHelper;
import com.ibm.commerce.ras.ECTrace;
import com.ibm.commerce.user.objects.BusinessProfileAccessBean;
import com.ibm.commerce.user.objects.MemberAccessBean;
import com.ibm.commerce.user.objects.MemberGroupMemberAccessBean;
import com.ibm.commerce.user.objects.MemberRoleAccessBean;
import com.ibm.commerce.user.objects.OrganizationAccessBean;
import com.ibm.commerce.user.objects.UserAccessBean;
import com.ibm.commerce.user.objects.UserRegistryAccessBean;
import com.ibm.commerce.usermanagement.commands.UserRegistrationAdminAddCmd;

public class RegisterRequisitionerExtCmdImpl extends TaskCommandImpl implements RegisterRequisitionerCmd {
	public static final String COPYRIGHT = "(c) Copyright International Business Machines Corporation 1996,2008";
	private static final String CLASS_NAME = RegisterRequisitionerExtCmdImpl.class.getName();

	private static final String TYPE_REGISTERED_USER = "R";

	private static final String REGISTRATION_QUALIFIER = "ProcurementRegistration";

	private boolean checkParametersOk = false;

	private boolean registrationSuccessful = false;

	private String reqId = null;

	private String reqName = null;

	private String email = null;

	private String deptName = null;

	private String postbackUrl = null;

	private String sessionId = null;

	private String sessionType = null;

	private String orderStatusUrl = null;

	private SessionInfo sessionInfo = null;

	private Long userId = null;

	private static final long DEFAULT_BUYER_ID = -1L;

	private long buyerId = -1L;

	private long supplierId = -1L;
	private Integer protocolId = null;

	private static final int CHANNEL_MGR = -26;

	protected static Object critsect = new Object();

	private void createMemberGroupMember() {
		String strMethodName = "createMemberGroupMember";
		boolean bTrace = ECTrace.traceEnabled(4L);
		if (bTrace) {
			ECTrace.entry(4L, CLASS_NAME, "createMemberGroupMember");
		}

		if ((buyerId != -1L) && (supplierId != -1L) && (userId != null)) {
			Long memberGroup = StoreHelper.findMemberGroupId(buyerId, supplierId, getProtocolId());

			if (memberGroup != null) {
				try {
					new MemberGroupMemberAccessBean(memberGroup, userId, "0");

				} catch (Exception e) {

					if (bTrace) {
						ECTrace.trace(4L, CLASS_NAME, "createMemberGroupMember", "EXCEPTION_OCCURED" + e);
					}
				}
			}
		}
		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "createMemberGroupMember");
		}
	}

	private void createNewUser() throws ECException {
		String strMethodName = "createNewUser";

		boolean bTrace = ECTrace.traceEnabled(4L);
		if (bTrace) {
			ECTrace.entry(4L, CLASS_NAME, "createNewUser");
		}

		Long lBuyOrgId = new Long(buyerId);

		try {
			UserAccessBean userBean = null;
			boolean isRequisitionerReg = false;

			synchronized (critsect) {
				BusinessProfileAccessBean aBean = findBusinessProfile(reqId, buyerId);

				if (aBean != null) {
					isRequisitionerReg = true;
					if (bTrace) {
						ECTrace.trace(4L, CLASS_NAME, "createNewUser",
								"Found Requisitioner with Requisitioner ID = " + reqId);
					}

					setUsersId(aBean.getUserIdInEntityType());
					UpdateSessionInfo();

					if (bTrace) {
						ECTrace.exit(4L, CLASS_NAME, "createNewUser", new Boolean(registrationSuccessful));
					}
					return;
				}

				OrganizationAccessBean orgABean = (OrganizationAccessBean) JpaEntityAccessBeanCacheUtil
						.newJpaEntityAccessBean(OrganizationAccessBean.class);
				orgABean.setInitKey_memberId(String.valueOf(lBuyOrgId));
				orgABean.instantiateEntity();
				String orgNameWithType = orgABean.getOrgEntityType().toLowerCase() + "="
						+ orgABean.getOrganizationName();

				TypedProperty createUserRequestProperties = new TypedProperty();
				createUserRequestProperties.put("URL", "NoURL");
				createUserRequestProperties.put("logonId", reqId);
				/* We hard coded Password for Requisitioner User as part of the POC's Scope */
				createUserRequestProperties.put("logonPassword", "<Hard_Coded_Password>");
				createUserRequestProperties.put("logonPasswordVerify", "<Hard_Coded_Password>");
				createUserRequestProperties.put("storeId", getStoreId());
				createUserRequestProperties.put("parentMember", orgNameWithType);
				createUserRequestProperties.put("profileType", "B");
				createUserRequestProperties.put("organizationDistinguishedName", orgNameWithType);
				createUserRequestProperties.put("appendRootOrganizationDN", true);
				createUserRequestProperties.put("email1", email);
				createUserRequestProperties.put("requistionerId", reqId);
				createUserRequestProperties.put("lastName", reqName);

				UserRegistrationAdminAddCmd UserRegAdminAddapi = (UserRegistrationAdminAddCmd) CommandFactory
						.createCommand("com.ibm.commerce.usermanagement.commands.UserRegistrationAdminAddCmd",
								getStoreId());
				if (UserRegAdminAddapi == null) {
					throw new ECApplicationException(ECMessage._ERR_CMD_CMD_NOT_FOUND, getClass().getName(),
							"performExecute");
				}

				UserRegAdminAddapi.setCommandContext(getCommandContext());
				UserRegAdminAddapi.setRequestProperties(createUserRequestProperties);
				UserRegAdminAddapi.setDefaultProperties(new TypedProperty());
				UserRegAdminAddapi.execute();
				TypedProperty createUserResponseProperties = UserRegAdminAddapi.getResponseProperties();

				setUsersId(createUserResponseProperties.getLong("userId"));

			}

			UpdateSessionInfo();

			MemberRoleAccessBean memRoleBean = new MemberRoleAccessBean(getUsersId(), new Integer(-26), lBuyOrgId);

			Vector results = MemberRegistrationAttributesHelper.getResolvedRolesForNewUser(getUsersId(),
					getStoreId().toString(), "ProcurementRegistration");

			if ((results != null) && (results.size() > 0)) {
				for (int i = 0; i < results.size(); i++) {
					Object[] objArray = (Object[]) results.get(i);
					Integer roleId = (Integer) objArray[0];
					Long orgId = (Long) objArray[1];
					memRoleBean = new MemberRoleAccessBean(getUsersId(), roleId, orgId);
				}
			}

			createMemberGroupMember();

			MemberAccessBean memBean = new MemberAccessBean();
			memBean.setInitKey_memberId(getUsersId().toString());
			memBean.setState("1");
			ServerJDBCHelperBean abFlush =

					(ServerJDBCHelperBean) SessionBeanHelper.lookupSessionBean(ServerJDBCHelperBean.class);
			abFlush.flush();
			registrationSuccessful = true;
		} catch (NoResultException e) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, CLASS_NAME, "createNewUser",
					ECMessageHelper.generateMsgParms(e.toString()), e, true);
		} catch (EntityExistsException e) {
			throw new ECSystemException(ECMessage._ERR_CREATE_EXCEPTION, CLASS_NAME, "createNewUser",
					ECMessageHelper.generateMsgParms(e.toString()), e, true);
		} catch (PersistenceException e) {
			throw new ECSystemException(ECMessage._ERR_REMOTE_EXCEPTION, CLASS_NAME, "createNewUser",
					ECMessageHelper.generateMsgParms(e.toString()), e, true);
		}

		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "createNewUser", new Boolean(registrationSuccessful));
		}
	}

	private byte[] generatePassword() throws ECSystemException {
		String strMethodName = "generatePassword";

		boolean bTrace = ECTrace.traceEnabled(4L);
		if (bTrace) {
			ECTrace.entry(4L, CLASS_NAME, "generatePassword");
		}

		byte[] password = null;
		try {
			Long aUserId = getCommandContext().getUserId();

			UserRegistryAccessBean userRegBean = (UserRegistryAccessBean) JpaEntityAccessBeanCacheUtil
					.newJpaEntityAccessBean(UserRegistryAccessBean.class);
			userRegBean.setInitKey_userId(String.valueOf(aUserId));
			userRegBean.instantiateEntity();
			password = userRegBean.getLogonPassword();

		} catch (NoResultException e) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, CLASS_NAME, "generatePassword",
					ECMessageHelper.generateMsgParms(e.toString()), e, true);
		}

		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "generatePassword");
		}
		return password;
	}

	private String generateSalt() throws ECSystemException {
		String strMethodName = "generateSalt";

		boolean bTrace = ECTrace.traceEnabled(4L);
		if (bTrace) {
			ECTrace.entry(4L, CLASS_NAME, "generateSalt");
		}

		String salt = null;
		try {
			Long aUserId = getCommandContext().getUserId();

			UserRegistryAccessBean userRegBean = (UserRegistryAccessBean) JpaEntityAccessBeanCacheUtil
					.newJpaEntityAccessBean(UserRegistryAccessBean.class);
			userRegBean.setInitKey_userId(String.valueOf(aUserId));
			userRegBean.instantiateEntity();
			salt = userRegBean.getSalt();

		} catch (NoResultException e) {
			throw new ECSystemException(ECMessage._ERR_FINDER_EXCEPTION, CLASS_NAME, "generateSalt",
					ECMessageHelper.generateMsgParms(e.toString()), e, true);
		}

		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "generateSalt");
		}
		return salt;
	}

	public Integer getProtocolId() {
		return protocolId;
	}

	public AccessVector getResources() throws ECException {
		OrganizationAccessBean orgAB = (OrganizationAccessBean) JpaEntityAccessBeanCacheUtil
				.newJpaEntityAccessBean(OrganizationAccessBean.class);
		orgAB.setInitKey_memberId(new Long(buyerId).toString());
		return new AccessVector(orgAB);
	}

	public Long getUsersId() {
		return userId;
	}

	public boolean isRegisteredSuccessfully() {
		return registrationSuccessful;
	}

	public void performExecute() throws ECException {
		String strMethodName = "performExecute";
		boolean bTrace = ECTrace.traceEnabled(4L);
		if (bTrace) {
			ECTrace.entry(4L, CLASS_NAME, "performExecute");
		}

		CacheRule.issueBaseCacheInvalidations(CacheConstants.EC_CACHE_CUSTOMERS_COLLECTION);

		if (!checkParametersOk) {
			if (bTrace) {
				ECTrace.trace(4L, CLASS_NAME, "performExecute", "validateParameters failed");
				ECTrace.exit(4L, CLASS_NAME, "performExecute");
			}
			return;
		}

		if (bTrace) {
			ECTrace.trace(4L, CLASS_NAME, "performExecute",
					"Register Requisitioner command parameters: requisitionerId=" + reqId);
		}

		BusinessProfileAccessBean aBean = findBusinessProfile(reqId, buyerId);

		if (aBean != null) {
			setUsersId(aBean.getUserIdInEntityType());
			UpdateSessionInfo();
		} else {
			createNewUser();
		}

		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "performExecute");
		}
	}

	public void setBuyerId(long aBuyerId) {
		buyerId = aBuyerId;
	}

	public void setDeptName(String aDeptName) {
		deptName = aDeptName;
	}

	public void setOrderStatusUrl(String anOrderStatusUrl) {
		orderStatusUrl = anOrderStatusUrl;
	}

	public void setPostbackUrl(String aPostbackUrl) {
		postbackUrl = aPostbackUrl;
	}

	public void setProtocolId(Integer aProtocol) {
		protocolId = aProtocol;
	}

	public void setReqId(String aReqId) {
		reqId = aReqId;
	}

	public void setReqName(String aReqName) {
		reqName = aReqName;
	}

	public void setSessionId(String aSessionId) {
		sessionId = aSessionId;
	}

	public void setSessionInfo(SessionInfo aSessionInfo) {
		sessionInfo = aSessionInfo;

		setReqId(sessionInfo.getReqId());
		setReqName(sessionInfo.getReqName());
		setDeptName(sessionInfo.getDeptName());
		setPostbackUrl(sessionInfo.getPostBackURL());
		setSessionId(sessionInfo.getSessionId());
		setSessionType(sessionInfo.getSessionType());
		setOrderStatusUrl(sessionInfo.getOrderStatusUrl());
		setProtocolId(new Integer(sessionInfo.getProcurementProtocolId()));
	}

	public void setSessionType(String aSessionType) {
		sessionType = aSessionType;
	}

	public void setSupplierId(long aSupplierId) {
		supplierId = aSupplierId;
	}

	public void setUsersId(Long aUserId) {
		userId = aUserId;
	}

	void UpdateSessionInfo() {
	}

	public void validateParameters() throws ECException {
		String strMethodName = "validateParameters";

		boolean bTrace = ECTrace.traceEnabled(4L);
		if (bTrace) {
			Object[] obj = { reqId };
			ECTrace.entry(4L, CLASS_NAME, "validateParameters", obj);
		}

		if ((reqId == null) || (reqId.trim().length() == 0)) {
			TypedProperty exceptionProperties = new TypedProperty();

			Status s = Status.getStatus(110, getCommandContext().getLocale());
			exceptionProperties.put("statusCode", s.getCode());
			exceptionProperties.put("statusText", s.getText());
			exceptionProperties.put("statusMessage", s.getMessage());
			exceptionProperties.put("procurementErrorCode", new Integer(110).toString());

			throw new ECApplicationException(ECMEMessage._ERR_PROCUREMENT_INVALID_REQUISITIONER_ID, CLASS_NAME,
					"validateParameters", "PunchOutSetupErrorView", exceptionProperties, true);
		}
		if ((buyerId != -1L) && (sessionInfo != null)) {
			checkParametersOk = true;
		}

		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "validateParameters");
		}
	}

	private static BusinessProfileAccessBean findBusinessProfile(String aReqId, long aBuyerOrgId)
			throws ECSystemException {
		String METHODNAME = "findBusinessProfile";
		boolean bTrace = ECTrace.traceEnabled(4L);
		boolean isRequisitionerReg = false;
		if (bTrace) {
			ECTrace.entry(4L, CLASS_NAME, "findBusinessProfile");
		}

		BusinessProfileAccessBean aBean = null;
		try {
			BusinessProfileAccessBean reqAB = new BusinessProfileAccessBean();

			Enumeration e = reqAB.findByRequisitionerId(aReqId);

			if (e.hasMoreElements()) {
				while ((e.hasMoreElements()) && (!isRequisitionerReg)) {
					aBean = (BusinessProfileAccessBean) e.nextElement();
					aBean.instantiateEntity();
					Long lOrgId = aBean.getOrganizationIdInEntityType();

					long orgId = -1L;
					if (lOrgId != null) {
						orgId = lOrgId.longValue();
					}
					if (orgId == aBuyerOrgId) {
						isRequisitionerReg = true;
						if (bTrace) {
							ECTrace.trace(4L, CLASS_NAME, "findBusinessProfile", "Found a requisitioner with ID = \""
									+ aReqId + "\" under organization \"" + orgId + "\".");
						}
					}
				}
				if ((!isRequisitionerReg) && (bTrace)) {
					ECTrace.trace(4L, CLASS_NAME, "findBusinessProfile", "Requisitioner with ID = \"" + aReqId
							+ "\" under organization \"" + aBuyerOrgId + "\" cannot be found.");
				}

			}
		} catch (NoResultException e) {
			isRequisitionerReg = false;
			if (bTrace) {
				ECTrace.trace(4L, CLASS_NAME, "findBusinessProfile",
						"Requisitioner with ID = \"" + aReqId + "\" cannot be found.");
			}
		}

		if (bTrace) {
			ECTrace.exit(4L, CLASS_NAME, "findBusinessProfile");
		}
		if (isRequisitionerReg) {
			return aBean;
		}
		return null;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}